from huggingface_hub import hf_hub_download
from ultralytics import YOLO

# 1. Download the weights safely to your local machine
print("Downloading model weights...")
model_path = hf_hub_download(
    repo_id="kendrickfff/waste-classification-yolov8-ken", 
    filename="yolov8n-waste-12cls-best.pt"
)

# 2. Load the model from the newly downloaded local path
print(f"Loading model from: {model_path}")
model = YOLO(model_path)

# 3. Verify it works
print("\nSupported Classes:")
print(model.names)